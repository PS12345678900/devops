import os
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

import yaml


BASE = Path(__file__).resolve().parent.parent / "data"
PB_DIR = BASE / "playbooks"
RB_DIR = BASE / "runbooks"
LG_DIR = BASE / "logs"


def ensure_dirs() -> None:
    PB_DIR.mkdir(parents=True, exist_ok=True)
    RB_DIR.mkdir(parents=True, exist_ok=True)
    LG_DIR.mkdir(parents=True, exist_ok=True)


def write_yaml(path: Path, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def write_text(path: Path, text: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def seed_playbooks() -> None:
    pb1 = {
        "id": "INCIDENT-APP-5XX",
        "title": "App 5xx spike",
        "services": ["payments-api"],
        "triggers": {"alerts": ["HTTP5xxRateHigh"], "symptoms": ["5xx>3%", "latency>400ms"]},
        "prerequisites": ["On-call acknowledged in PagerDuty", "Access to logs and metrics"],
        "diagnosis": [
            {"text": "Check 5xx error code distribution", "command": "kubectl logs deploy/payments-api --since=15m | findstr /R \"HTTP/1.1\\\" 5\""},
            {"text": "Inspect dependency timeouts", "command": "kubectl logs deploy/payments-api | findstr TimeoutException"},
        ],
        "remediation": [
            {
                "text": "Roll back to last stable version",
                "priority": "high",
                "command": "kubectl rollout undo deploy/payments-api",
                "verify": "5xx < 1% for 10m, p95 < 250ms",
                "rollback": "none",
            },
            {
                "text": "Increase upstream client timeouts by 1s",
                "priority": "medium",
                "command": "kubectl set env deploy/payments-api CLIENT_TIMEOUT_MS=2000",
                "verify": "5xx trending down, no saturation on dependency",
                "rollback": "kubectl set env deploy/payments-api CLIENT_TIMEOUT_MS=1000",
            },
        ],
        "references": [{"label": "SLO runbook", "url": "https://docs.internal/slo/app-availability"}],
        "owners": ["sre@company.com"],
        "tags": ["app", "5xx", "k8s"],
    }
    pb2 = {
        "id": "INCIDENT-DB-LATENCY",
        "title": "Database latency spike",
        "services": ["payments-db"],
        "triggers": {"alerts": ["DBLatencyHigh"], "symptoms": ["p95>200ms", "timeouts"]},
        "prerequisites": ["Access to cluster and metrics", "On-call SRE present"],
        "diagnosis": [
            {"text": "Check read vs write latency trend", "command": "aws rds describe-db-instances --db-instance-identifier payments"},
            {"text": "Inspect active connections", "command": "psql -c \"select * from pg_stat_activity limit 20\""},
        ],
        "remediation": [
            {
                "text": "Scale read replicas by +1",
                "priority": "high",
                "command": "aws rds modify-db-cluster --scaling-configuration ...",
                "verify": "p95 < 150ms for 5m",
                "rollback": "revert scaling parameters",
            },
            {
                "text": "Throttle slow queries > 1s in db-proxy",
                "priority": "medium",
                "command": "kubectl exec deploy/db-proxy -- throttle --gt 1000ms",
                "verify": "p95 trending down; CPU < 70%",
                "rollback": "remove throttle rule",
            },
        ],
        "references": [{"label": "Runbook", "url": "https://docs.internal/runbooks/db-latency#scale-replicas"}],
        "owners": ["sre@company.com"],
        "tags": ["db", "latency", "rds"],
    }
    pb3 = {
        "id": "INCIDENT-KAFKA-LAG",
        "title": "Kafka consumer lag",
        "services": ["orders-consumer"],
        "triggers": {"alerts": ["ConsumerLagHigh"], "symptoms": ["lag>50k", "behind by hours"]},
        "prerequisites": ["Access to Kafka cluster", "Offsets topic readable"],
        "diagnosis": [
            {"text": "Check consumer group lag", "command": "kafka-consumer-groups.sh --describe --group orders --bootstrap-server localhost:9092"},
        ],
        "remediation": [
            {
                "text": "Scale consumer replicas +2",
                "priority": "high",
                "command": "kubectl scale deploy/orders-consumer --replicas=4",
                "verify": "lag decreasing steadily",
                "rollback": "scale back to previous replica count",
            },
            {
                "text": "Increase fetch.max.bytes",
                "priority": "low",
                "command": "kubectl set env deploy/orders-consumer FETCH_MAX_BYTES=52428800",
                "verify": "no OOM; lag reduction observed",
                "rollback": "restore previous setting",
            },
        ],
        "references": [{"label": "Kafka docs", "url": "https://kafka.apache.org/documentation/"}],
        "owners": ["data-eng@company.com"],
        "tags": ["kafka", "lag"],
    }
    pb4 = {
        "id": "INCIDENT-DISK-FULL",
        "title": "Disk nearly full",
        "services": ["file-service"],
        "triggers": {"alerts": ["DiskUsageHigh"], "symptoms": [">85% usage"]},
        "prerequisites": ["SSH access"],
        "diagnosis": [
            {"text": "Find largest directories", "command": "du -xh /var | sort -rh | head -n 20"},
        ],
        "remediation": [
            {
                "text": "Rotate and compress logs",
                "priority": "high",
                "command": "logrotate -f /etc/logrotate.conf",
                "verify": "usage < 80%",
                "rollback": "restore old logs from backup if needed",
            },
            {
                "text": "Expand disk volume by 10%",
                "priority": "medium",
                "command": "lvextend -l +10%FREE /dev/mapper/vg-root && resize2fs /dev/mapper/vg-root",
                "verify": "capacity increased",
                "rollback": "revert LVM change if supported",
            },
        ],
        "references": [{"label": "Storage standards", "url": "https://docs.internal/storage"}],
        "owners": ["platform@company.com"],
        "tags": ["disk", "linux"],
    }
    write_yaml(PB_DIR / "app_5xx.yaml", pb1)
    write_yaml(PB_DIR / "db_latency.yaml", pb2)
    write_yaml(PB_DIR / "kafka_lag.yaml", pb3)
    write_yaml(PB_DIR / "disk_full.yaml", pb4)


def seed_runbooks() -> None:
    rb1 = """# App 5xx Spike Runbook
## Preconditions
- On-call acknowledged
## Diagnosis
- Check 5xx distribution
- Inspect dependency timeouts
## Remediation: Rollback
- kubectl rollout undo deploy/payments-api
"""
    rb2 = """# Database Latency Spike Runbook
## Diagnosis
- Inspect read vs write latency
- Inspect active connections
## Remediation
- Scale read replicas
- Throttle slow queries
"""
    write_text(RB_DIR / "app_5xx.md", rb1)
    write_text(RB_DIR / "db_latency.md", rb2)


def gen_log_lines(service: str, start: datetime, minutes: int) -> List[str]:
    lines: List[str] = []
    ts = start
    for m in range(minutes):
        # baseline
        for _ in range(random.randint(5, 10)):
            lines.append(f"{ts.isoformat()}Z {service} INFO request ok path=/health latency_ms={random.randint(15,60)}")
        # spikes
        if 5 <= m <= 15:
            lines.append(f"{ts.isoformat()}Z {service} ERROR upstream timeout service=orders elapsed_ms={random.randint(800,1500)}")
            lines.append(f"{ts.isoformat()}Z nginx ACCESS 502 path=/checkout latency_ms={random.randint(450,700)}")
        ts = ts + timedelta(minutes=1)
    return lines


def seed_logs() -> None:
    start = datetime.utcnow()
    app_lines = gen_log_lines("payments-api", start, 30)
    write_text(LG_DIR / "payments_api.log", "\n".join(app_lines))
    db_lines = gen_log_lines("payments-db", start, 30)
    write_text(LG_DIR / "payments_db.log", "\n".join(db_lines))


def main() -> None:
    ensure_dirs()
    seed_playbooks()
    seed_runbooks()
    seed_logs()
    print(f"Synthetic data written under {BASE}")


if __name__ == "__main__":
    main()


