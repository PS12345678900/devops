from __future__ import annotations

import math
import os
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from .data_loader import Chunk, load_from_base_dir
from .embedding import Embedder
from .vector_store import ChromaVectorStore, InMemoryVectorStore


def build_index(
    base_dir: str,
    backend: str,
    collection_name: str,
    embedder: Embedder,
    append: bool = True,
    where_delete: Optional[Dict[str, Any]] = None,
    batch_size: int = 256,
    progress: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    if progress:
        progress("Loading documents...")
    chunks: List[Chunk] = load_from_base_dir(base_dir)
    if progress:
        progress(f"Loaded {len(chunks)} chunks from {base_dir}")

    if backend == "chroma":
        vs = ChromaVectorStore(persist_dir=os.path.join(base_dir, "..", ".chroma"), collection_name=collection_name)
    else:
        vs = InMemoryVectorStore()

    if not append:
        if progress:
            progress("Clearing existing index...")
        if backend == "chroma":
            vs.delete_where(where_delete)
        else:
            vs.clear()

    # Prepare data
    ids = [c.id for c in chunks]
    docs = [c.text for c in chunks]
    mds = [c.metadata for c in chunks]

    if progress:
        progress("Computing embeddings...")
    all_embeddings: List[np.ndarray] = []
    for i in range(0, len(docs), batch_size):
        batch = docs[i : i + batch_size]
        embs = embedder.embed_texts(batch)
        all_embeddings.append(embs)
        if progress:
            progress(f"Embedded {min(i + batch_size, len(docs))}/{len(docs)}")
    if not all_embeddings:
        return {"chunks": 0, "backend": backend, "collection": collection_name}
    embeddings = np.vstack(all_embeddings)

    if progress:
        progress("Upserting into vector store...")
    if backend == "chroma":
        vs.upsert(ids=ids, embeddings=embeddings, metadatas=mds, documents=docs)
    else:
        vs.upsert(ids=ids, embeddings=embeddings, metadatas=mds, documents=docs)

    return {"chunks": len(chunks), "backend": backend, "collection": collection_name}


