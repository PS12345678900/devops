from __future__ import annotations

import glob
import hashlib
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import yaml


@dataclass
class Chunk:
    id: str
    text: str
    metadata: Dict[str, Any]


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _file_sha256(path: str) -> str:
    with open(path, "rb") as f:
        data = f.read()
    return hashlib.sha256(data).hexdigest()


def load_from_base_dir(base_dir: str) -> List[Chunk]:
    playbooks = glob.glob(os.path.join(base_dir, "playbooks", "*.yaml"))
    runbooks = glob.glob(os.path.join(base_dir, "runbooks", "*.md"))
    logs = glob.glob(os.path.join(base_dir, "logs", "*.log"))

    chunks: List[Chunk] = []
    for path in playbooks:
        chunks.extend(_load_playbook_yaml(path))
    for path in runbooks:
        chunks.extend(_load_runbook_md(path))
    for path in logs:
        chunks.extend(_load_logs_text(path))
    return chunks


def _stable_chunk_id(source_path: str, anchor: str, idx: int) -> str:
    base = f"{source_path}::{anchor}::{idx}"
    return _sha256_text(base)


def _load_playbook_yaml(path: str) -> List[Chunk]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except Exception:
        return []
    if not isinstance(data, dict):
        return []
    chunks: List[Chunk] = []
    doc_sha = _file_sha256(path)
    base_md: Dict[str, Any] = {
        "source_path": path,
        "doc_sha": doc_sha,
        "type": "playbook",
        "id": data.get("id"),
        "title": data.get("title"),
        "services": data.get("services", []),
        "tags": data.get("tags", []),
    }
    # Prereqs (single chunk)
    if data.get("prerequisites"):
        text = "Prerequisites:\n" + "\n".join([f"- {p}" for p in data.get("prerequisites", [])])
        cid = _stable_chunk_id(path, "prerequisites", 0)
        md = {**base_md, "section": "prerequisites"}
        chunks.append(Chunk(id=cid, text=text, metadata=md))
    # Diagnosis
    for i, step in enumerate(data.get("diagnosis", []) or []):
        if isinstance(step, dict):
            text = step.get("text", "")
            command = step.get("command")
        else:
            text = str(step)
            command = None
        body = text.strip()
        if command:
            body += f"\nCommand: {command}"
        cid = _stable_chunk_id(path, "diagnosis", i)
        md = {**base_md, "section": "diagnosis"}
        chunks.append(Chunk(id=cid, text=body, metadata=md))
    # Remediation
    for i, step in enumerate(data.get("remediation", []) or []):
        text = ""
        command = None
        verify = None
        rollback = None
        priority = None
        if isinstance(step, dict):
            text = step.get("text", "")
            command = step.get("command")
            verify = step.get("verify")
            rollback = step.get("rollback")
            priority = step.get("priority")
        else:
            text = str(step)
        lines = [text.strip()]
        if command:
            lines.append(f"Command: {command}")
        if verify:
            lines.append(f"Verify: {verify}")
        if rollback:
            lines.append(f"Rollback: {rollback}")
        body = "\n".join([ln for ln in lines if ln])
        cid = _stable_chunk_id(path, "remediation", i)
        md = {
            **base_md,
            "section": "remediation",
            "priority": str(priority or "").lower() if priority else None,
        }
        chunks.append(Chunk(id=cid, text=body, metadata=md))
    # References
    refs = data.get("references", []) or []
    if refs:
        for i, ref in enumerate(refs):
            label = ""
            url = ""
            if isinstance(ref, dict):
                label = ref.get("label", "")
                url = ref.get("url", "")
            else:
                label = str(ref)
            body = f"Reference: {label} {url}".strip()
            cid = _stable_chunk_id(path, "references", i)
            md = {**base_md, "section": "references"}
            chunks.append(Chunk(id=cid, text=body, metadata=md))
    return chunks


_MD_SECTION_SPLIT = re.compile(r"^##\s+", flags=re.MULTILINE)


def _load_runbook_md(path: str) -> List[Chunk]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return []
    doc_sha = _file_sha256(path)
    base_md: Dict[str, Any] = {
        "source_path": path,
        "doc_sha": doc_sha,
        "type": "runbook",
        "title": os.path.splitext(os.path.basename(path))[0],
    }
    sections = _MD_SECTION_SPLIT.split(text)
    # sections[0] is header preface; keep it as context if non-empty
    chunks: List[Chunk] = []
    idx = 0
    if sections and sections[0].strip():
        cid = _stable_chunk_id(path, "intro", idx)
        md = {**base_md, "section": "intro"}
        chunks.append(Chunk(id=cid, text=sections[0].strip(), metadata=md))
        idx += 1
    for sec in sections[1:]:
        # first line until newline is the heading title
        title_line, _, body = sec.partition("\n")
        body_text = body.strip()
        if not body_text:
            continue
        cid = _stable_chunk_id(path, f"section:{title_line.strip()}", idx)
        md = {**base_md, "section": title_line.strip()}
        chunks.append(Chunk(id=cid, text=body_text, metadata=md))
        idx += 1
    return chunks


def _load_logs_text(path: str, window: int = 200) -> List[Chunk]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except Exception:
        return []
    doc_sha = _file_sha256(path)
    base_md: Dict[str, Any] = {
        "source_path": path,
        "doc_sha": doc_sha,
        "type": "log",
        "title": os.path.basename(path),
    }
    chunks: List[Chunk] = []
    if not lines:
        return chunks
    idx = 0
    for i in range(0, len(lines), window):
        window_lines = lines[i : i + window]
        cid = _stable_chunk_id(path, "logs", idx)
        md = {**base_md, "section": f"logs[{i}:{i+len(window_lines)}]"}
        chunks.append(Chunk(id=cid, text="\n".join(window_lines), metadata=md))
        idx += 1
    return chunks


