import os
import sys
import time
from typing import Any, Dict, List, Optional

import numpy as np
import streamlit as st

# Ensure project root is on sys.path so `import app.*` works when running the script directly
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


# Minimal .env loader (no extra dependency): loads KEY=VALUE pairs into environment
def _load_dotenv_from_root() -> None:
    env_path = os.path.join(_PROJECT_ROOT, ".env")
    if not os.path.exists(env_path):
        return
    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for raw in f.read().splitlines():
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                # Don't override existing explicit environment
                if key and key not in os.environ:
                    os.environ[key] = val
    except Exception:
        # Fail silently; users can still set env vars via shell
        pass


_load_dotenv_from_root()

from app.embedding import Embedder
from app.indexing import build_index
from app.vector_store import ChromaVectorStore
from app.generation import synthesize_checklist_rule_based, synthesize_checklist_with_llm


st.set_page_config(page_title="Incident Response Assistant", layout="wide")
st.title("Incident Response Assistant")
st.caption("Ask questions grounded in your existing ChromaDB knowledge. Upsert new files anytime.")


@st.cache_resource(show_spinner=False)
def get_chroma_store(collection_name: str) -> ChromaVectorStore:
    persist_dir = os.path.abspath(os.path.join(_PROJECT_ROOT, ".chroma"))
    os.makedirs(persist_dir, exist_ok=True)
    return ChromaVectorStore(persist_dir=persist_dir, collection_name=collection_name)


@st.cache_resource(show_spinner=False)
def get_embedder() -> Embedder:
    return Embedder(batch_size=256)


def sidebar_controls() -> Dict[str, Any]:
    st.sidebar.header("Settings")
    collection_name = st.sidebar.text_input("Collection name (Chroma)", value="incidents_openai")
    top_k = st.sidebar.number_input("Top K", min_value=5, max_value=50, value=20, step=1)
    use_llm = st.sidebar.checkbox("Use OpenAI for synthesis", value=True)
    st.sidebar.markdown("---")
    st.sidebar.caption("Requires OPENAI_API_KEY for embeddings (and synthesis if enabled).")
    return {
        "collection_name": collection_name,
        "top_k": int(top_k),
        "use_llm": use_llm,
    }


def upsert_controls(cfg: Dict[str, Any]) -> None:
    st.subheader("Optional: Upsert New Data")
    st.caption("If you already have a Chroma index, you can skip this.")
    uploaded = st.file_uploader("Upload files to upsert (YAML/MD/LOG/TXT)", type=["yaml","yml","md","log","txt"], accept_multiple_files=True)
    do_upload = st.button("Upsert Uploaded Files")

    try:
        embedder = get_embedder()
    except Exception as e:
        st.error(f"Embedding init failed: {e}")
        return

    if do_upload and uploaded:
        staging = os.path.join(_PROJECT_ROOT, "staging_uploads")
        os.makedirs(staging, exist_ok=True)
        pb_dir = os.path.join(staging, "playbooks"); os.makedirs(pb_dir, exist_ok=True)
        rb_dir = os.path.join(staging, "runbooks"); os.makedirs(rb_dir, exist_ok=True)
        lg_dir = os.path.join(staging, "logs"); os.makedirs(lg_dir, exist_ok=True)
        for f in uploaded:
            name = os.path.basename(f.name)
            ext = os.path.splitext(name)[1].lower()
            if ext in [".yaml", ".yml"]:
                target = os.path.join(pb_dir, name)
            elif ext == ".md":
                target = os.path.join(rb_dir, name)
            else:
                target = os.path.join(lg_dir, name)
            with open(target, "wb") as out:
                out.write(f.getbuffer())
        info = st.empty()
        def progress2(msg: str) -> None:
            info.info(msg)
        res = build_index(
            base_dir=staging,
            backend="chroma",
            collection_name=cfg["collection_name"],
            embedder=embedder,
            append=True,
            where_delete=None,
            batch_size=256,
            progress=progress2,
        )
        info.success(f"Upserted {res.get('chunks',0)} chunks from uploads")


def retrieval_and_guidance_ui(cfg: Dict[str, Any]) -> None:
    st.subheader("Ask")
    prompt = st.text_area("Your prompt", value="payments-api experiencing 5xx spike after deploy. What should I do?")
    do_ask = st.button("Ask", type="primary")
    show_sources = st.checkbox("Show sources", value=True)

    store = get_chroma_store(cfg["collection_name"])
    try:
        embedder = get_embedder()
    except Exception as e:
        st.error(f"Embedding init failed: {e}")
        return

    if not do_ask:
        return

    with st.spinner("Retrieving…"):
        q_emb = embedder.embed_query(prompt)
        try:
            retrieved = store.query(query_embedding=q_emb, top_k=cfg["top_k"], where=None)
        except Exception as e:
            st.error(f"Query error: {e}")
            return

    st.caption(f"Retrieved {len(retrieved)} chunks")
    if not retrieved:
        st.warning("No results found in the current collection. Consider upserting data first.")
        return

    if cfg["use_llm"]:
        items = synthesize_checklist_with_llm(prompt, retrieved, severity="P2")
    else:
        items = synthesize_checklist_rule_based(prompt, retrieved, severity="P2")

    st.markdown("#### Guided steps")
    md_lines: List[str] = []
    for i, it in enumerate(items):
        title = it.get("label") or (it.get("section", "") or "Action").title()
        st.markdown(f"**Step {i+1}. {title}**")
        details = it.get("details", "").strip()
        if details and details != title:
            st.write(details)
        if it.get("command"):
            st.write("Command:")
            st.code(it["command"], language="bash")
        if it.get("verify"):
            st.write(f"Verify: {it['verify']}")
        if it.get("rollback"):
            st.write(f"Rollback: {it['rollback']}")
        if show_sources and it.get("ref"):
            st.caption(f"Ref: {it['ref']}")
        st.markdown("---")
        # Build export markdown
        md_lines.append(f"- [ ] {title}")
        if details and details != title:
            md_lines.append(f"  - Context: {details.splitlines()[0]}")
        if it.get("command"):
            md_lines.append(f"  - Command: `{it['command']}`")
        if it.get("verify"):
            md_lines.append(f"  - Verify: {it['verify']}")
        if it.get("rollback"):
            md_lines.append(f"  - Rollback: {it['rollback']}")
        if show_sources and it.get("ref"):
            md_lines.append(f"  - Ref: {it['ref']}")
    md_text = "\n".join(md_lines)
    st.download_button("Download Markdown", data=md_text, file_name="incident_checklist.md", mime="text/markdown")


def main() -> None:
    cfg = sidebar_controls()
    st.markdown("Use your existing collection, or upsert more data if needed.")

    # Inform the user if the collection is empty; no automatic directory upsert
    try:
        import chromadb  # type: ignore
        persist_dir = os.path.join(_PROJECT_ROOT, ".chroma")
        os.makedirs(persist_dir, exist_ok=True)
        client = chromadb.PersistentClient(path=persist_dir)
        coll = client.get_or_create_collection(name=cfg["collection_name"], metadata={"hnsw:space": "cosine"})
        if coll.count() == 0:
            st.info("Current collection is empty. Upload files and click 'Upsert Uploaded Files' to populate it.")
    except Exception:
        pass

    upsert_controls(cfg)
    retrieval_and_guidance_ui(cfg)


if __name__ == "__main__":
    main()


