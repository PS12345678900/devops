from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np


def _cosine_sim_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-12)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-12)
    return a_norm @ b_norm.T


@dataclass
class RetrievedChunk:
    document: str
    metadata: Dict[str, Any]
    score: float


class InMemoryVectorStore:
    def __init__(self) -> None:
        self.ids: List[str] = []
        self.embeddings: Optional[np.ndarray] = None
        self.metadatas: List[Dict[str, Any]] = []
        self.documents: List[str] = []

    def clear(self) -> None:
        self.ids = []
        self.embeddings = None
        self.metadatas = []
        self.documents = []

    def upsert(
        self,
        ids: Sequence[str],
        embeddings: np.ndarray,
        metadatas: Sequence[Dict[str, Any]],
        documents: Sequence[str],
    ) -> None:
        if embeddings.shape[0] != len(ids) or len(ids) != len(metadatas) or len(ids) != len(documents):
            raise ValueError("Mismatched lengths in upsert")

        id_to_index = {id_: i for i, id_ in enumerate(self.ids)}
        # Update existing or append new
        for i, cid in enumerate(ids):
            if cid in id_to_index:
                idx = id_to_index[cid]
                self.metadatas[idx] = dict(metadatas[i])
                self.documents[idx] = documents[i]
                if self.embeddings is not None:
                    self.embeddings[idx] = embeddings[i]
            else:
                self.ids.append(cid)
                self.metadatas.append(dict(metadatas[i]))
                self.documents.append(documents[i])
                if self.embeddings is None:
                    self.embeddings = embeddings[i : i + 1].copy()
                else:
                    self.embeddings = np.vstack([self.embeddings, embeddings[i : i + 1]])

    def delete_where(self, where: Optional[Dict[str, Any]] = None) -> None:
        if not where:
            self.clear()
            return
        keep_indices: List[int] = []
        for i, md in enumerate(self.metadatas):
            if not _matches_where(md, where):
                keep_indices.append(i)
        self.ids = [self.ids[i] for i in keep_indices]
        self.metadatas = [self.metadatas[i] for i in keep_indices]
        self.documents = [self.documents[i] for i in keep_indices]
        if self.embeddings is not None:
            self.embeddings = self.embeddings[keep_indices]

    def query(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievedChunk]:
        if self.embeddings is None or self.embeddings.shape[0] == 0:
            return []
        # Filter by where
        candidate_indices = list(range(len(self.documents)))
        if where:
            candidate_indices = [i for i, md in enumerate(self.metadatas) if _matches_where(md, where)]
            if not candidate_indices:
                return []
        embs = self.embeddings[candidate_indices]
        sims = _cosine_sim_matrix(query_embedding.reshape(1, -1), embs)[0]
        top_idx = np.argsort(-sims)[:top_k]
        results: List[RetrievedChunk] = []
        for offset_idx in top_idx:
            i = candidate_indices[int(offset_idx)]
            results.append(
                RetrievedChunk(
                    document=self.documents[i],
                    metadata=self.metadatas[i],
                    score=float(sims[int(offset_idx)]),
                )
            )
        return results


def _matches_where(md: Dict[str, Any], where: Dict[str, Any]) -> bool:
    for k, v in where.items():
        if isinstance(v, dict) and "$in" in v:
            vals = v["$in"]
            if md.get(k) not in vals:
                return False
        else:
            if md.get(k) != v:
                return False
    return True


class ChromaVectorStore:
    def __init__(self, persist_dir: str, collection_name: str) -> None:
        import chromadb  # type: ignore

        self.client = chromadb.PersistentClient(path=persist_dir)
        # Create or get
        self.collection = self.client.get_or_create_collection(name=collection_name, metadata={"hnsw:space": "cosine"})

    def clear(self) -> None:
        self.collection.delete()

    def delete_where(self, where: Optional[Dict[str, Any]] = None) -> None:
        if not where:
            self.collection.delete()
        else:
            self.collection.delete(where=where)

    @staticmethod
    def _normalize_metadata(md: Dict[str, Any]) -> Dict[str, Any]:
        norm: Dict[str, Any] = {}
        for k, v in md.items():
            # Chroma requires scalars or None
            if isinstance(v, (str, int, float, bool)) or v is None:
                norm[k] = v
            elif isinstance(v, (list, tuple, set)):
                # Join list-like values into a comma-separated string
                try:
                    norm[k] = ", ".join([str(x) for x in v])
                except Exception:
                    norm[k] = str(v)
            else:
                # Fallback: stringify
                norm[k] = str(v)
        return norm

    def upsert(
        self,
        ids: Sequence[str],
        embeddings: np.ndarray,
        metadatas: Sequence[Dict[str, Any]],
        documents: Sequence[str],
    ) -> None:
        safe_mds = [self._normalize_metadata(md) for md in metadatas]
        self.collection.upsert(
            ids=list(ids),
            embeddings=[emb.astype(float).tolist() for emb in embeddings],
            metadatas=safe_mds,
            documents=list(documents),
        )

    def query(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievedChunk]:
        # If the collection is empty, short-circuit to avoid backend errors
        try:
            if hasattr(self.collection, "count") and self.collection.count() == 0:
                return []
        except Exception:
            # If count fails, proceed to query and let it handle errors
            pass
        q = self.collection.query(
            query_embeddings=[query_embedding.astype(float).tolist()],
            n_results=top_k,
            where=where,
        )
        results: List[RetrievedChunk] = []
        if not q or not q.get("documents"):
            return results
        docs = q["documents"][0]
        mds = q.get("metadatas", [[]])[0]
        dists = q.get("distances", [[]])[0]  # lower is better if distance; convert to similarity-ish
        # Convert distances to pseudo-similarity
        sims = [1.0 - float(d) if d is not None else 0.0 for d in dists]
        for doc, md, sim in zip(docs, mds, sims):
            results.append(RetrievedChunk(document=doc, metadata=md or {}, score=sim))
        return results


