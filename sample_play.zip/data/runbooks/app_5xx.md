# App 5xx Spike Runbook
## Preconditions
- On-call acknowledged
## Diagnosis
- Check 5xx distribution
- Inspect dependency timeouts
## Remediation: Rollback
- kubectl rollout undo deploy/payments-api
