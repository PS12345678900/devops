# Database Latency Spike Runbook
## Diagnosis
- Inspect read vs write latency
- Inspect active connections
## Remediation
- Scale read replicas
- Throttle slow queries
